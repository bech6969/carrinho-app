# App Carrinho — painel Android para inversor WEG CVW300

Tablet Android → USB OTG → adaptador USB-RS485 → CVW300 (XC9-05 = A, XC9-06 = B, + GND)

## Gerar o APK (sem instalar nada) — GitHub
1. Crie um repositório (pode ser privado) em github.com e envie esta pasta inteira.
2. Aba **Actions** → "Gerar APK" roda sozinho (ou clique em *Run workflow*).
3. Ao terminar, baixe o artefato **carrinho-apk** (zip com o `app-debug.apk`).
4. Passe o APK para o tablet e instale (permita "instalar apps desconhecidos").

## Alternativa — Android Studio
Abra a pasta no Android Studio → Build → Build APK(s).

## Ajustes
Tudo em `app/src/main/java/br/com/carrinho/painel/Config.kt`:
- `PARIDADE` conforme P0311 do inversor (padrão 1 = par)
- `SENHA_P0000` senha de acesso para alterar parâmetros
- `V_BAT_VAZIA` / `V_BAT_CHEIA` da sua bateria
- `MOSTRAR_KMH` (km/h vem do P0008, calculado pelo inversor com P0124/P0125)
- `VEL_MAX_MODO` (rpm dos modos ECO/NORMAL/SPORT, gravado em P0134 — confira no manual)

## No inversor
P0223 = 5 · P0224 = 2 · P0313 = desabilita geral · P0314 = 0,5 s · pedal no analógico.

## Segurança embutida
- F↔R só com o carrinho parado
- App fora da tela, adaptador removido ou 5 falhas seguidas → neutro
- Comando enviado a cada 100 ms (watchdog do inversor para o carrinho se o app travar)
- Primeiro teste com as rodas suspensas

## Tela de Configurações (⚙ no painel)
- Todos os parâmetros configuráveis do manual do CVW300 G2, por grupo, com busca
- "Ler do inversor" → edite → "Salvar": grava só o que mudou, confere lendo de volta
- Bloqueia gravação com o carrinho em movimento; avisos ⚠ nos parâmetros críticos
- "Valores padrão" preenche com o padrão de fábrica (só grava ao tocar em Salvar)
